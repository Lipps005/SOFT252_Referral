/***
 * @author Samuel Lippett
 * @date 28/07/2020
 */
package my.models;

public class Patient extends User{
   
   public Patient(String UID)
   {
      this.UID = UID;
   }

   
   
   //public void requestAppointment(){}
}
